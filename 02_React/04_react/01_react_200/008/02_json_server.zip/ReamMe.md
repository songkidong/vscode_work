﻿# jsonserver 설치할것 ( -g 글로벌 설치 : 1번만 설치하면 됨 )
npm i -g json-server